
function calculate() {


    if (document.getElementById("#input_query_default") != null) {
         query = document.getElementById("#input_query_default").value;
    } else {
        query = document.getElementById("#input_query").value;
    }

    document.getElementById("#papers_section").innerHTML = '<div class="d-flex justify-content-center"><div class="spinner-grow text-primary" role="status" style="width: 10rem; height: 10rem;"><span class="sr-only">Loading...</span></div></div>';
    document.getElementById("#authors_section").innerHTML = ''
    document.getElementById("#authors_header").innerHTML = ""
    
    $.ajax({
        data : {
            query: query,

        },
        type : 'POST',
        url : '/search_articles'
    })
    .done(function(data) {

        if (data.error) {
            console.log(data.error);
        }
        else {
            document.getElementById("#authors_section").innerHTML = data["author_results"];
            // document.getElementById("#papers_section").innerHTML = data["paper_results"];
            
            console.log(data["author_results"])
            if (data["author_results"] != "") 
                document.getElementById("#authors_header").innerHTML = "Authors for the query: " + query;
            else document.getElementById("#authors_header").innerHTML = "No authors found for the query: " + query;

            console.log(data["paper_results"])
            if (!data["paper_results"].includes("<h2>No papers found for") )
                document.getElementById("#papers_section").innerHTML = data["paper_results"];
            // else document.getElementById("#papers_section").innerHTML = "<h4>No papers found for the query: " + query + "</h4>";
        }

    });
};


