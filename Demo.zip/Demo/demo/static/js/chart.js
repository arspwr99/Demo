const ctx = document.getElementById('lineChart').getContext('2d');

// Sample data (replace with your actual data)
const years = [2018, 2019, 2020, 2021, 2022];
const data1 = [50, 65, 80, 70, 90]; // Line 1 data (e.g., Sales)
const data2 = [30, 40, 55, 45, 60]; // Line 2 data (e.g., Expenses)

const chart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: years,
    datasets: [{
      label: 'Line 1',
      data: data1,
      borderColor: 'red',
      backgroundColor: 'rgba(255, 99, 132, 0.2)',
    }, {
      label: 'Line 2',
      data: data2,
      borderColor: 'blue',
      backgroundColor: 'rgba(54, 162, 235, 0.2)',
    }]
  },
  options: {
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
});
