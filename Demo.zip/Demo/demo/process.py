from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.exceptions import HTTPException

import requests
import re 
from analyze_paper import get_citations, filter_self_citing


global S2_API_KEY


app = Flask(__name__)

@app.route('/')
def index():
	return render_template('form.html')

@app.route('/about')
def about():
	return render_template('about.html')

@app.route('/people')
def people():
	return render_template('people.html')

@app.route('/search_articles', methods=['POST'])
def search_articles():
	query = request.form['query']
	fields = "title,year,abstract,authors"
	url = f"http://api.semanticscholar.org/graph/v1/paper/search/bulk?query={query}&fields={fields}&year=2024-"
	r = requests.get(url).json()

	# print(f"Will retrieve an estimated {r['total']} documents")
	retrieved = 0
	papers = []
	while True:
		if "data" in r:
			retrieved += len(r["data"])
			print(f"Retrieved {retrieved} papers...")
			for paper in r["data"]:
				papers.append(paper)
		if "token" not in r:
			break
		r = requests.get(f"{url}&token={r['token']}").json()
		print(f"Done! Retrieved {retrieved} papers total")

	if len(papers) == 0:
		html_result = f"<h4>No papers found for the query: {query}</h4>"
	else:
		html_result = f"<h4>Found {len(papers)} papers for the query: {query}</h4><hr>"

	for i in range(len(papers)):

		author_list = ""
		for author in papers[i]["authors"]:
			author_name = author["name"]
			author_id = author["authorId"]
			author_list += f"<a class='btn btn-light' href='author/{author_id}' >{author_name}</a>"

		html_result += f"""<h5>{papers[i]['title']}</h5>
        {author_list}
		<p style='text-align: justify;'><strong>Abstract:</strong> {papers[i]['abstract'] if papers[i]['abstract'] != None else '-'}</p>
        <hr>"""

	html_result += "<hr>"
	print (html_result)
	return jsonify({'paper_results': html_result, 'author_results': resolve_author(query)})


def resolve_author(desc: str):
	req_fields = 'authorId,name,url,affiliations,paperCount,citationCount,hIndex'

	if re.match('\\d+', desc):  # ID given
		rsp = requests.get(f'https://api.semanticscholar.org/graph/v1/author/{desc}',
							params={'fields': req_fields})
		rsp.raise_for_status()
		return rsp.json()

	else:  # search
		rsp = requests.get('https://api.semanticscholar.org/graph/v1/author/search',
							params={'query': desc, 'fields': req_fields})
		rsp.raise_for_status()

		results = rsp.json()
		author_box = f""

		results['data'] = sorted(results['data'], key=lambda x: x['citationCount'], reverse=True)
		print (results)
		for author in results['data']: 

			if author["paperCount"] <= 1 and author["affiliations"] == []:
				continue 
			# user_link_image = "static/images/user.jpg"

			if author['citationCount'] != 1:
				t = f"{author['citationCount']} citations"
			else:
				t = f"{author['citationCount']} citation"

			if author['affiliations'] != []:
				aff = f"<p class='citations'>{','.join(author['affiliations'])}</p>"
			else:
				aff = ""
			author_box += f"""
						<div class='profile-box'>
						<a href='author/{author['authorId']}' class='profile-name'>{author['name']}</a>
						<p class='citations'>{t}</p>
						{aff}
						<p class="citations">h-index: {author['hIndex']}</p>
						</div>
        
"""
	return author_box

# f"""
# 						<div class='profile-box'>
# 						# <img src='{user_link_image}' alt='Profile Picture' class='profile-image'>
# 						<a href='author/{author['authorId']}' class='profile-name'>{author['name']}</a>
# 						<p class='citations'>{author['citationCount']} citation</p>
# 						</div>
        
# """



def load_author_data(author_id):
	req_fields = 'authorId,name,url,affiliations,paperCount,citationCount,hIndex,homepage'

	if re.match('\\d+', author_id):  # ID given
		try:
			rsp = requests.get(f'https://api.semanticscholar.org/graph/v1/author/{author_id}',
								params={'fields': req_fields})
			rsp.raise_for_status()

		except requests.exceptions.HTTPError as error:
			if error.response.status_code == 429:
				# Handle 429 error specifically
				return render_template('429.html', message="Too Many Requests."), 429
			
		return rsp.json()

	else:  # search
		try:
			rsp = requests.get('https://api.semanticscholar.org/graph/v1/author/search',
								params={'query': author_id, 'fields': req_fields})
			rsp.raise_for_status()
		except requests.exceptions.HTTPError as error:
			if error.response.status_code == 429:
				# Handle 429 error specifically
				return render_template('429.html', message="Too Many Requests."), 429

		results = rsp.json()
		return results 
	
def get_author_papers(author_id):
    rsp = requests.get(f'https://api.semanticscholar.org/graph/v1/author/{author_id}/papers',
                       params={'fields': 'title,url,year,authors', 'limit': 1000})
    rsp.raise_for_status()
    return rsp.json()['data']


def analyze_author(authorId):
	global S2_API_KEY
	papers = get_author_papers(authorId)
	print (papers)
	total_self_citations, total_external_citations, total_citations = 0, 0, 0
	exceptions = []

	html_block = ""
	for i, paper in enumerate(papers):
		# try:
			
			citations = get_citations(paper["paperId"], S2_API_KEY)
			self_citations = list(filter_self_citing([{"authorId": authorId}], citations))
			external_citations = len(citations) - len(self_citations)

			author_list = ""
			for author in paper["authors"]:
				author_name = author["name"]
				author_id = author["authorId"]
				author_list += f"<a class='btn btn-light' href='/author/{author_id}'>{author_name}</a>"

			html_block += f"""
				<li class="list-group-item">
            		<a href="{paper['url']}"  target='_blank'>{paper['title']}</a>
					<span class="badge badge-primary badge-pill">{len(citations)}</span>
					<span class="badge badge-danger badge-pill">{len(self_citations)}</span>
					<span class="badge badge-success badge-pill">{external_citations}</span>
					<span class="badge badge-light badge-pill">{paper['year']}</span>
					<br>
					{author_list}
          		</li>
				
"""

			print (f"{i}/{len(papers)}:", paper["title"], "has:")
			print (f"   {len(citations)} citations which {len(self_citations)} are self citations and {external_citations} are external citations.")

			total_self_citations += len(self_citations)
			total_external_citations += external_citations
			total_citations += len(citations)
		# except Exception as e:
		# 	print ("Warning: There was an error while processing the paper:", paper["title"])
		# 	exceptions.append(paper["title"])
		# 	print (e) 

	return total_citations, total_external_citations, total_self_citations, html_block



@app.route('/author/<author_id>')
def author(author_id):
	data = load_author_data(author_id)
	if isinstance(data, tuple):
		return render_template('429.html', message="Too Many Requests.")

	total_citations, total_external_citations, total_self_citations, papers_html = analyze_author(author_id)
	return render_template('profile.html', author_name=data['name'],
						 affiliation=", ".join(data['affiliations']), 
						 paper_count=data['paperCount'], 
						 citation_count=data['citationCount'],
						 url = data['url'], 
						 homepage = data['homepage'],
						 hIndex = data['hIndex'],
						 total_external_citations = total_external_citations,
						 total_self_citations=total_self_citations,
						 papers_html = papers_html)


@app.errorhandler(429)
def too_many_requests(error):
  # Retry information might be available in the response headers
  retry_after = error.headers.get('Retry-After')

  message = "Too Many Requests. Please try again later."
  if retry_after:
      message += f" You can retry after {retry_after} seconds."

  return render_template('429.html', message=message), 429



@app.route('/download')
def download_file():
    # Replace with the actual path to your file
    path_to_file = "static/Thesis.pdf"
    return send_file(path_to_file, as_attachment=True)



if __name__ == '__main__':
	S2_API_KEY = "B16vCpZ2ka346nksEYHlO7ZJMIRQmOFQ24QI5fok"
	app.run(host='0.0.0.0', port=8090, debug=True)